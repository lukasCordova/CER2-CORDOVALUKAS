
from django.contrib.auth import login, logout, authenticate
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Evento, Inscripcion
from .forms import RegistroForm, LoginForm
from django.contrib import messages


# Create your views here.s
def inicio(request):
    return render(request, 'core/index.html')

def eventos(request):
    eventos = Evento.objects.order_by('id')
    
    return render(request, 'core/eventos.html', {
        'eventos' : eventos
    })

def comunidad(request):
    return render(request, 'core/comunidad.html')

def contacto(request):
    return render(request, 'core/contacto.html')

def iniciar(request):

    # Inicio de sesión
    if request.method == 'POST':
        form = LoginForm(request=request, data=request.POST)
        print('llegan los datos del login: ')
        print(request.POST)
        username = request.POST['username']
        password = request.POST['password']

        # Validación
        usuario = authenticate(request, username=username, password=password)
        if usuario is not None:
            login(request, usuario)
            messages.success(request, '¡Inicio de sesión exitoso!')
            return redirect('index')
        else:
            print('Usuario no existe y se redirige a login con mensaje')
            messages.error(request, 'Usuario o contraseña incorrectos')

    else:
        form = LoginForm()
    return render(request, 'core/iniciar.html', {
        'form' : form,
    })


def cerrar(request):
    logout(request)
    messages.success(request, '¡Sesión cerrada correctamente!')
    return redirect('index')  

def registro(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        print('llega el usuario: ')
        print(request.POST)
        
        # Validacion
        if form.is_valid():
            # Se guarda
            usuario = form.save()
            messages.success(request, 'Usuario registrado correctamente!')
            login(request, usuario)
            return redirect('index')
        else:
            print('form no valido:')
            print(form.errors)
            messages.error(request, 'Hubo un error al validar el formulario')
    else:
        form = RegistroForm()

    return render(request, 'core/registro.html', {'form': form})

@login_required # 
def inscribir_evento(request, pk):
    evento = get_object_or_404(Evento, pk=pk)
    
    if evento.plazas_restantes() <= 0:
        messages.error(request, f'Error: El evento "{evento.titulo}" ya no tiene plazas disponibles.')
        return redirect('eventos')

    # Búsqueda de inscripcion
    inscripcion_existente = Inscripcion.objects.filter(
        usuario=request.user, 
        evento=evento
    ).first()
    
    if inscripcion_existente:
        if not inscripcion_existente.anulada:
            messages.warning(request, f'Ya estás inscrito en el evento "{evento.titulo}".')
            return redirect('eventos')
        
        else:
            inscripcion_existente.anulada = False # Reactivar 
            inscripcion_existente.save()
            messages.success(request, f'Tu inscripción en "{evento.titulo}" se reactivó con éxito.')


    # Si no existe
    else:
        Inscripcion.objects.create(usuario=request.user, evento=evento, anulada=False)
        messages.success(request, f'Te has inscrito con éxito en el evento "{evento.titulo}".')
        
    return redirect('mis_eventos') 



@login_required 
def mis_eventos(request):
    inscripciones_activas = Inscripcion.objects.filter(
        usuario=request.user, 
        anulada=False
    )

    return render(request, 'core/mis_eventos.html', {
        'inscripciones': inscripciones_activas
    })


@login_required 
def anular_registro(request, pk):
    # buscar la inscripción 
    inscripcion = get_object_or_404(Inscripcion, pk=pk, usuario=request.user)
    
    # actualizar
    inscripcion.anulada = True
    inscripcion.save()
    messages.success(request, 'Inscripción anulada correctamente')

    return redirect('mis_eventos')