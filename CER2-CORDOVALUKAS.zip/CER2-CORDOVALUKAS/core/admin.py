from django.contrib import admin

# Register your models here. 
from . import models
admin.site.register(models.Usuario)
admin.site.register(models.Inscripcion)

class InscripcionInline(admin.TabularInline):
    model = models.Inscripcion
    fields = ('usuario', 'fecha_inscripcion', 'anulada')
    readonly_fields = ('usuario', 'fecha_inscripcion')


@admin.register(models.Evento)
class EventoAdmin(admin.ModelAdmin):

    list_display = ('titulo', 'fecha', 'lugar', 'plazas_totales', 'plazas_restantes', 'valor_recaudado') 
    fields = ('titulo', 'fecha', 'lugar', 'plazas_totales', 'valor', 'imagen_url', 'valor_recaudado')
    readonly_fields = ('valor_recaudado',)

    inlines = [InscripcionInline]
    def plazas_restantes(self, obj):
        return obj.plazas_restantes()

    def valor_recaudado(self, obj):
        recaudado = obj.valor_recaudado()
        return f"${recaudado:,.0f}" # Moneda