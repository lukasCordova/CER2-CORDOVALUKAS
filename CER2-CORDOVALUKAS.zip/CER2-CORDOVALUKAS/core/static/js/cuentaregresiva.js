//CUENTA REGRESIVA

const elementoCuentaRegresiva = document.getElementById("cuentaRegresiva");
const fechaEvento = new Date("2025-10-31T22:00:00").getTime();
function actualizaCuentaRegresiva() {
    const ahora = new Date().getTime();
    const distancia = fechaEvento - ahora;

    if (distancia < 0) {
    elementoCuentaRegresiva.innerHTML = "¡El evento ha comenzado!";
    clearInterval(contador);
    return;
    } //para que termine cuando ya ocurrió

    const dias = Math.floor(distancia / (1000 * 60 * 60 * 24));
    const horas = Math.floor((distancia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutos = Math.floor((distancia % (1000 * 60 * 60)) / (1000 * 60));
    const segundos = Math.floor((distancia % (1000 * 60)) / 1000);

    elementoCuentaRegresiva.innerHTML =
    `${dias}d ${horas}h ${minutos}m ${segundos}s`;
}
const contador = setInterval(actualizaCuentaRegresiva, 1000);
actualizaCuentaRegresiva();