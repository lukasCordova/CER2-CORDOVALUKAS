

//COMENTARIOS
//-COMENTARIOS RECIENTES
let comentarios = [
    {
        nombre:"PedroCopec",
        mensaje: "Primera en serviciooo",
        fecha: "8/9/2025",
        hora: "22:35:10"
    },
    {
        nombre:"Sofiausm",
        mensaje: "Se cae el aulaaa",
        fecha: "9/9/2025",
        hora: "4:29:09"
    },
    {
        nombre:"Raperomaldito",
        mensaje: "wena matiahhh",
        fecha: "9/9/2025",
        hora: "4:20:00"
    },
    {
        nombre:"Raperobendito",
        mensaje: "wena dj pereee",
        fecha: "9/9/2025",
        hora: "5:00:00"
    },
    {
        nombre:"Piñera",
        mensaje: "cuando taller acuático",
        fecha: "9/9/2025",
        hora: "6:56:56"
    },
    {
        nombre:"Xurrasquin",
        mensaje: "soy de conceeee cuando en conce",
        fecha: "9/9/2025",
        hora: "8:00:10"
    },
    {
        nombre:"elMesias",
        mensaje: "acompañadme hermanos",
        fecha: "1/1/0",
        hora: "0:00:01"
    }


];
function agregarComentario(nombreN, mensajeN, fechaN, horaN){
    comentarios.unshift({nombre: nombreN, mensaje: mensajeN, fecha: fechaN, hora:horaN});
    mostrarComentarios();

}
function mostrarComentarios(){
    const listaComentarios =  document.getElementById("lista-comentarios");
    listaComentarios.innerHTML = "";
    for (let i = 0; i < comentarios.length; i++) {
        if(i === 10){
            break;
        }
        let c = comentarios[i];
        console.log(c);
        
        let li = document.createElement("li");
        li.className = "list-group-item container-fluid d-flex justify-content-between";
        
        let divComentario = document.createElement("div");
        divComentario.innerHTML = `<strong>${c.nombre}:</strong> ${c.mensaje}`;
        let divFechaHora = document.createElement("div");
        divFechaHora.innerHTML = `<span>F ${c.fecha} H ${c.hora}</span>`;
        li.appendChild(divComentario);
        li.appendChild(divFechaHora);
        
        listaComentarios.appendChild(li);
    }

}
const form = document.getElementById('form-comentario');
function procesarComentario(event){
    event.preventDefault();

    const nombre = document.getElementById("nombre-form").value;
    const mensaje = document.getElementById("mensaje-form").value;
    const ahora = new Date();
    const fecha = ahora.toLocaleDateString();
    const hora = ahora.toLocaleTimeString();    

    agregarComentario(nombre, mensaje, fecha, hora);

    form.reset(); 
}
mostrarComentarios();
form.addEventListener("submit", procesarComentario)
