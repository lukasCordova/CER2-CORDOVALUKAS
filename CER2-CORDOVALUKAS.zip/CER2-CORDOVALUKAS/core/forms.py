from django import forms
from .models import Usuario
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm


class RegistroForm(UserCreationForm):
    # campos adicionales
    email = forms.EmailField(required=True)
    rut = forms.CharField(max_length=12, required=True)

    class Meta:
        model = Usuario
        fields = ['username', 'email', 'rut', 'password1', 'password2']


class LoginForm(AuthenticationForm):
    # form listo pero le doy diseño
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Los campos por defecto son 'username' y 'password'
        self.fields['username'].widget.attrs.update({
            "class": "form-control",
            "placeholder": "Usuario"
        })
        self.fields['password'].widget.attrs.update({
            "class": "form-control",
            "placeholder": "Contraseña"
        })


