from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

# Create your models here.

class Usuario(AbstractUser):
    rut = models.CharField(max_length=12, unique=True, blank=False, null=False)

    def __str__(self):
        return f"{self.username}, ({self.rut})" if self.rut else self.username
    


class Evento(models.Model):
    titulo = models.CharField(max_length=200)
    fecha = models.DateTimeField()
    lugar = models.CharField(max_length=100, default="")
    imagen_url = models.URLField(max_length=500, null=True, blank=True)
    valor = models.IntegerField(default=0)
    plazas_totales = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.id}, {self.titulo}"
    
    def plazas_restantes(self):
        inscritos = Inscripcion.objects.filter(evento=self, anulada=False).count()
        # diferencia
        return self.plazas_totales - inscritos

    def valor_recaudado(self):
        plazas_vendidas = Inscripcion.objects.filter(evento=self, anulada=False).count()

        total = plazas_vendidas * self.valor
        return total


class Inscripcion(models.Model):
    #conexion entre tablas
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE) 
    evento = models.ForeignKey(Evento, on_delete=models.CASCADE)
    fecha_inscripcion = models.DateTimeField(default=timezone.now)
    anulada = models.BooleanField(default=False) 

    class Meta:
        # hace un unico par evento-usuario
        unique_together = ('usuario', 'evento') 
        
    def __str__(self):
        return f'{self.usuario.username} inscrito en {self.evento.titulo}'